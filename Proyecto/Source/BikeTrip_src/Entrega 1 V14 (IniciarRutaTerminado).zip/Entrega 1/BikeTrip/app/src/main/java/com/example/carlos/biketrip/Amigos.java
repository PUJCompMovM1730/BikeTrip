package com.example.carlos.biketrip;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

/**
 * Created by carlos on 27/08/17.
 */

public class Amigos extends Fragment{

    View v;
    ImageButton ibAmigo;
    ImageButton btnBookmark;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.activity_amigos, container, true);
        ibAmigo = v.findViewById(R.id.ibtnPerfiAmigo);
        btnBookmark = v.findViewById(R.id.btnBookmark);

        ibAmigo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Perfil.class);
                startActivity(intent);
            }
        });

        btnBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(),"Ruta agregada satisfactoriamente",
                        Toast.LENGTH_LONG).show();
            }
        });


        return super.onCreateView(inflater, container, savedInstanceState);



    }

}
