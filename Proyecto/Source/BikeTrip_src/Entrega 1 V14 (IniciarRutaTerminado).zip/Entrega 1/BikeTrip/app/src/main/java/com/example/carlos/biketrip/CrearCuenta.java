package com.example.carlos.biketrip;

import android.content.Intent;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import android.widget.Toast;

public class CrearCuenta extends AppCompatActivity {

    Button bcrear;
    Button bcancelar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_cuenta);

        bcrear = (Button)findViewById(R.id.btnConfirmCrear);
        bcancelar = (Button)findViewById(R.id.btnCancelarCrear);

        bcrear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getBaseContext(),"Verificar datos e insertar en BD",
                        Toast.LENGTH_LONG).show();
                Intent intent= new Intent(getBaseContext(), MenuPrincipal.class);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    finishAffinity();
                }
                startActivity(intent);


            }
        });

        bcancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
