package com.example.carlos.biketrip;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class Perfil extends AppCompatActivity {

    ImageButton ibAgregar;
    ImageButton ibEliminar;
    ImageButton ibMsj;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);


        ibEliminar = (ImageButton) findViewById(R.id.ibtnDelF);
        ibAgregar = (ImageButton)findViewById(R.id.ibtnAddF);
        ibMsj = (ImageButton)findViewById(R.id.ibtnMsg);

        ibAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"Amigo agregado",
                        Toast.LENGTH_LONG).show();

            }
        });

        ibEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"Amigo eliminado",
                        Toast.LENGTH_LONG).show();
            }
        });

        ibMsj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(),"Aqui abre un dialogo para escribir el mensaje",
                        Toast.LENGTH_LONG).show();
            }
        });

    }
}
