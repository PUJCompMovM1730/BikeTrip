package entidades;

import java.util.Date;
import java.util.GregorianCalendar;
//import java.util.GregorianCalendar;

/**
 * Created by user-pc on 25/10/2017.
 */

public class RutaEnt {
    private long latInicio;
    private long lonInicio;
    private long latFinal;
    private long lonFinal;
    private String descripcion;
    private String nombre;
    private Date tiempo;
    private String idUsuario;
    private int distancia;

    public RutaEnt() {
        //this.tiempo= new GregorianCalendar();
    }

    public int getDistancia() {
        return distancia;
    }

    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    public long getLatInicio() {
        return latInicio;
    }

    public void setLatInicio(long latInicio) {
        this.latInicio = latInicio;
    }

    public long getLonInicio() {
        return lonInicio;
    }

    public void setLonInicio(long lonInicio) {
        this.lonInicio = lonInicio;
    }

    public long getLatFinal() {
        return latFinal;
    }

    public void setLatFinal(long latFinal) {
        this.latFinal = latFinal;
    }

    public long getLonFinal() {
        return lonFinal;
    }

    public void setLonFinal(long lonFinal) {
        this.lonFinal = lonFinal;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getTiempo() {
        return tiempo;
    }

    public void setTiempo(Date tiempo) {
        this.tiempo = tiempo;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }
}